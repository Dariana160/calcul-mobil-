
package com.example.myapplication

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

private val Cream = Color(0xFFFFF8F5)
private val Pink = Color(0xFFE7A8B8)
private val Dark = Color(0xFF35262D)
private val Muted = Color(0xFF89777E)
private val White = Color.White

data class ClothingItem(
    val id: Int,
    val name: String,
    val category: String,
    val price: Double,
    val image: String
)

private val categories = listOf(
    "Toate",
    "Tricouri",
    "Bluze și cămăși",
    "Pantaloni",
    "Pantaloni scurți",
    "Fuste",
    "Hanorace și pulovere",
    "Geci și jachete",
    "Încălțăminte",
    "Seturi complete",
    "Rochii",
    "Accesorii"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                FashionMirrorApp(applicationContext)
            }
        }
    }
}

@Composable
private fun FashionMirrorApp(context: Context) {
    var products by remember { mutableStateOf<List<ClothingItem>>(emptyList()) }
    var selectedCategory by remember { mutableStateOf("Toate") }
    var search by remember { mutableStateOf("") }
    var favorites by remember { mutableStateOf(setOf<Int>()) }
    var showFavorites by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var usingDemo by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()

    fun reload() {
        scope.launch {
            loading = true
            error = null
            usingDemo = false

            try {
                val onlineProducts = withTimeout(10000) {
                    fetchAllProducts()
                }

                products = onlineProducts

                if (onlineProducts.isEmpty()) {
                    error = "Catalogul online nu conține produse vestimentare."
                }
            } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException) {
                    throw e
                }

                products = demoProducts
                usingDemo = true
                error = if (demoProducts.isEmpty()) {
                    "Catalogul nu este disponibil. Verifică internetul."
                } else {
                    null
                }
            } finally {
                loading = false
            }
        }
    }

    LaunchedEffect(Unit) {
        favorites = context
            .getSharedPreferences("fashion_mirror", Context.MODE_PRIVATE)
            .getStringSet("favorites", emptySet())
            ?.mapNotNull { it.toIntOrNull() }
            ?.toSet() ?: emptySet()

        reload()
    }

    val visibleProducts = products.filter { item ->
        val categoryMatch = selectedCategory == "Toate" ||
                belongsToCategory(item, selectedCategory)

        val searchMatch = search.isBlank() ||
                item.name.contains(search, ignoreCase = true) ||
                item.category.contains(search, ignoreCase = true)

        val favoriteMatch = !showFavorites || item.id in favorites

        categoryMatch && searchMatch && favoriteMatch
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Cream
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            Spacer(Modifier.height(20.dp))

            Text(
                text = "FASHION MIRROR",
                fontSize = 25.sp,
                fontWeight = FontWeight.Black,
                color = Dark
            )

            Spacer(Modifier.height(3.dp))

            Text(
                text = "Inspiră-te. Combină. Creează-ți stilul.",
                fontSize = 13.sp,
                color = Muted
            )

            Spacer(Modifier.height(18.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                HeaderButton(
                    text = "Catalog",
                    selected = !showFavorites,
                    modifier = Modifier.weight(1f)
                ) {
                    showFavorites = false
                }

                HeaderButton(
                    text = "♥ Favorite",
                    selected = showFavorites,
                    modifier = Modifier.weight(1f)
                ) {
                    showFavorites = true
                }
            }

            Spacer(Modifier.height(14.dp))

            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Caută un articol...") },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Pink,
                    unfocusedBorderColor = Color(0xFFE5D7DC),
                    focusedContainerColor = White,
                    unfocusedContainerColor = White
                )
            )

            Spacer(Modifier.height(15.dp))

            Text(
                text = "CATEGORII",
                color = Muted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(Modifier.height(9.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { category ->
                    val selected = selectedCategory == category

                    Surface(
                        modifier = Modifier.clickable {
                            selectedCategory = category
                        },
                        shape = RoundedCornerShape(24.dp),
                        color = if (selected) Dark else White
                    ) {
                        Text(
                            text = category,
                            modifier = Modifier.padding(
                                horizontal = 14.dp,
                                vertical = 10.dp
                            ),
                            color = if (selected) White else Dark,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = if (showFavorites) "FAVORITELE MELE"
                    else selectedCategory.uppercase(),
                    color = Dark,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.weight(1f)
                )

                Text(
                    text = "${visibleProducts.size} produse",
                    color = Muted,
                    fontSize = 12.sp
                )
            }

            Spacer(Modifier.height(10.dp))

            when {
                loading -> {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = Pink)
                            Spacer(Modifier.height(12.dp))
                            Text("Se încarcă produsele...", color = Muted)
                        }
                    }
                }

                error != null -> {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(error.orEmpty(), color = Dark)
                            Spacer(Modifier.height(12.dp))
                            Button(
                                onClick = { reload() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Dark
                                )
                            ) {
                                Text("Încearcă din nou")
                            }
                        }
                    }
                }

                visibleProducts.isEmpty() -> {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                if (showFavorites) "Nu ai articole favorite încă."
                                else "Nu există produse în această categorie.",
                                color = Dark,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(
                                if (usingDemo) "Acestea sunt produse demonstrative."
                                else "Catalogul demo nu include toate tipurile de haine.",
                                color = Muted,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                else -> {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentPadding = PaddingValues(bottom = 24.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(
                            items = visibleProducts,
                            key = { it.id }
                        ) { item ->
                            ProductCard(
                                item = item,
                                favorite = item.id in favorites,
                                onFavorite = {
                                    val updated = if (item.id in favorites) {
                                        favorites - item.id
                                    } else {
                                        favorites + item.id
                                    }

                                    favorites = updated

                                    context.getSharedPreferences(
                                        "fashion_mirror",
                                        Context.MODE_PRIVATE
                                    ).edit()
                                        .putStringSet(
                                            "favorites",
                                            updated.map { it.toString() }.toSet()
                                        )
                                        .apply()
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HeaderButton(
    text: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier.clickable { onClick() },
        color = if (selected) Pink else White,
        shape = RoundedCornerShape(14.dp)
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(vertical = 12.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            color = Dark,
            fontWeight = FontWeight.SemiBold,
            fontSize = 13.sp
        )
    }
}

@Composable
private fun ProductCard(
    item: ClothingItem,
    favorite: Boolean,
    onFavorite: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column {
            Box {
                AsyncImage(
                    model = item.image,
                    contentDescription = item.name,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(175.dp)
                        .background(Color(0xFFFFFCFA))
                        .clip(
                            RoundedCornerShape(
                                topStart = 18.dp,
                                topEnd = 18.dp
                            )
                        ),
                    contentScale = ContentScale.Fit
                )

                Surface(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                        .clickable { onFavorite() },
                    shape = RoundedCornerShape(50),
                    color = White
                ) {
                    Text(
                        text = if (favorite) "♥" else "♡",
                        modifier = Modifier.padding(
                            horizontal = 9.dp,
                            vertical = 5.dp
                        ),
                        color = if (favorite) Pink else Dark,
                        fontSize = 21.sp
                    )
                }
            }

            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = item.name,
                    color = Dark,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    minLines = 2
                )

                Spacer(Modifier.height(5.dp))

                Text(
                    text = String.format(Locale("ro", "RO"), "%.2f lei", item.price),
                    color = Dark,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = item.category.replace("-", " "),
                    color = Muted,
                    fontSize = 10.sp,
                    maxLines = 1
                )
            }
        }
    }
}

private fun belongsToCategory(
    item: ClothingItem,
    selected: String
): Boolean {
    val title = item.name.lowercase()
    val category = item.category.lowercase()

    return when (selected) {
        "Tricouri" ->
            category == "tops" &&
                    listOf("shirt", "t-shirt", "tshirt", "top", "tee")
                        .any { title.contains(it) } &&
                    !title.contains("dress")

        "Bluze și cămăși" ->
            category == "mens-shirts" ||
                    listOf("blouse", "button-up shirt", "formal shirt")
                        .any { title.contains(it) }

        "Pantaloni" ->
            listOf("trouser", "pants", "jeans", "legging", "cargo pants")
                .any { title.contains(it) }

        "Pantaloni scurți" ->
            listOf("shorts", "bermuda").any { title.contains(it) }

        "Fuste" ->
            listOf("skirt", "mini skirt", "midi skirt", "maxi skirt")
                .any { title.contains(it) }

        "Hanorace și pulovere" ->
            listOf("hoodie", "sweatshirt", "sweater", "pullover", "cardigan")
                .any { title.contains(it) }

        "Geci și jachete" ->
            listOf("jacket", "coat", "bomber", "parka", "blazer")
                .any { title.contains(it) }

        "Încălțăminte" -> category.contains("shoes")

        "Seturi complete" ->
            listOf("matching set", "co-ord", "two piece", "two-piece", "tracksuit")
                .any { title.contains(it) }

        "Rochii" -> category == "womens-dresses"

        "Accesorii" ->
            category in setOf(
                "womens-bags",
                "womens-jewellery",
                "womens-watches",
                "sunglasses"
            )

        else -> false
    }
}

private suspend fun fetchAllProducts(): List<ClothingItem> =
    withContext(Dispatchers.IO) {
        val connection = URL(
            "https://dummyjson.com/products?limit=0"
        ).openConnection() as HttpURLConnection

        try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 8000
            connection.readTimeout = 8000
            connection.useCaches = false

            val code = connection.responseCode

            if (code !in 200..299) {
                throw IllegalStateException("Catalog indisponibil: HTTP $code")
            }

            val response = connection.inputStream
                .bufferedReader()
                .use { it.readText() }

            val json = JSONObject(response)
            val array = json.getJSONArray("products")
            val result = mutableListOf<ClothingItem>()

            val allowedCategories = setOf(
                "tops",
                "mens-shirts",
                "womens-dresses",
                "womens-shoes",
                "mens-shoes",
                "womens-bags",
                "womens-jewellery",
                "womens-watches",
                "sunglasses"
            )

            for (i in 0 until array.length()) {
                val product = array.getJSONObject(i)
                val title = product.optString("title", "")
                val category = product.optString("category", "")
                val price = product.optDouble("price", 0.0)

                val image = product.optString("thumbnail", "").ifBlank {
                    val images = product.optJSONArray("images")
                    if (images != null && images.length() > 0) {
                        images.optString(0, "")
                    } else {
                        ""
                    }
                }

                if (
                    title.isNotBlank() &&
                    category in allowedCategories &&
                    image.startsWith("https://")
                ) {
                    result.add(
                        ClothingItem(
                            id = product.optInt("id"),
                            name = title,
                            category = category,
                            price = price,
                            image = image
                        )
                    )
                }
            }

            result.distinctBy { it.id }
        } finally {
            connection.disconnect()
        }
    }

private val demoProducts = listOf(
    ClothingItem(
        9001, "Tricou casual", "tops", 49.99,
        "https://dummyjson.com/image/400x500/fff0f5/35262d?text=T-shirt"
    ),
    ClothingItem(
        9002, "Cămașă elegantă", "mens-shirts", 89.99,
        "https://dummyjson.com/image/400x500/fff0f5/35262d?text=Shirt"
    ),
    ClothingItem(
        9003, "Rochie de zi", "womens-dresses", 129.99,
        "https://dummyjson.com/image/400x500/fff0f5/35262d?text=Dress"
    ),
    ClothingItem(
        9004, "Pantofi casual", "womens-shoes", 159.99,
        "https://dummyjson.com/image/400x500/fff0f5/35262d?text=Shoes"
    ),
    ClothingItem(
        9005, "Geantă de mână", "womens-bags", 99.99,
        "https://dummyjson.com/image/400x500/fff0f5/35262d?text=Bag"
    ),
    ClothingItem(
        9006, "Ochelari de soare", "sunglasses", 59.99,
        "https://dummyjson.com/image/400x500/fff0f5/35262d?text=Sunglasses"
    )
)
